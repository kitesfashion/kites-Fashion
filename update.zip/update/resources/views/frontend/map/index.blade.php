@extends('frontend.master')

@section('mainContent')
	<section class="fashioner haslayout section-padding background-size">
		<div class="container"> 
			<div class="clearfix"></div>
			<div id="map_wrapper">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d228.02002893905083!2d90.39042090474612!3d23.87825248452654!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c52db2b6e5c7%3A0x2a3143301540fe42!2sKites%20NEBC!5e0!3m2!1sen!2sbd!4v1580193274533!5m2!1sen!2sbd" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
			</div>
		</div>
	</section>
@endsection