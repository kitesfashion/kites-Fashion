@extends('frontend.master')
@section('mainContent')
	<section class="fashioner haslayout section-padding background-size">
		<div class="container"> 
			<div class="col-md-12 col-sm-12" style="min-height: 200px;">
				

			</div>
			<div class="clearfix"></div>
			<div id="map_wrapper">
				<div id="map_canvas" class="mapping"></div>
			</div>
		</div>
	</section>

@endsection