<div class="footer-link">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
          <p class="copyright">Copyright © {{Date('Y')}} Kites. All Rights Reserved.</p>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 text-right">
        <p class="copyright" style="font-size:12px;">Developed by &nbsp;
          <a href="https://technoparkbd.com/" target="_blank" style="color: #fff;">
            Techno Park Bangladesh
          </a>
        </p>
        </div>
      </div>
    </div>
  </div>