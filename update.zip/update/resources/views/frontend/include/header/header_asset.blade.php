<link rel="stylesheet" href="{{ asset("public/frontend/assets/%40fortawesome/fontawesome-free/css/all.min.css") }}">
<link rel="stylesheet" href="{{ asset("public/frontend/assets/css/bootstrap.min.css") }}">
<link rel="stylesheet" href="{{ asset("public/frontend/assets/css/font-awesome.css") }}">
<link rel="stylesheet" href="{{ asset("public/frontend/assets/css/colorbox.css") }}">
<link rel="stylesheet" href="{{ asset("public/frontend/assets/css/jcf.css") }}">
<link rel="stylesheet" href="{{ asset("public/frontend/assets/css/prettyPhoto.css") }}">
<link rel="stylesheet" href="{{ asset("public/frontend/assets/css/owl.carousel.css") }}">
<link rel="stylesheet" href="{{ asset("public/frontend/assets/css/owl.theme.css") }}">
<link rel="stylesheet" href="{{ asset("public/frontend/assets/css/flaticon.css") }}">
<link rel="stylesheet" href="{{ asset("public/frontend/assets/css/icomoon.css") }}">
<link rel="stylesheet" href="{{ asset("public/frontend/assets/css/transitions.css") }}">
<link rel="stylesheet" href="{{ asset("public/frontend/assets/css/main.css") }}">
<link rel="stylesheet" href="{{ asset("public/frontend/assets/css/color.css") }}">
<link rel="stylesheet" href="{{ asset("public/frontend/assets/css/skin_black.css") }}">
<link rel="stylesheet" href="{{ asset("public/frontend/assets/css/responsive.css") }}">
<link rel="stylesheet" href="{{ asset("public/frontend/assets/css/custome_style.css") }}">
<link href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css" rel="stylesheet"/>
<script src="{{ asset("public/frontend") }}/assets/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>