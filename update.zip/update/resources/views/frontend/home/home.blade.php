@extends('frontend.master')

@section('mainContent')
    @include('frontend.home.element.over_view_section')
    @include('frontend.home.element.collection_product')
@endsection