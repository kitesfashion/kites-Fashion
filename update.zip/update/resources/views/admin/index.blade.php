@extends('admin.layouts.master_origin')

@section('content')

@endsection

