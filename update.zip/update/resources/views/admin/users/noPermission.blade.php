@extends('admin.layouts.master')

@section('content')
    <h3 class="card-title" style="text-align: center;font-size: 54px;color: #d41010;">Sorry</h3>
    <h4 class="card-title" style="text-align: center;font-size: 30px;color: #e63030;">You Have No Permission for This Action</h4>

@endsection


