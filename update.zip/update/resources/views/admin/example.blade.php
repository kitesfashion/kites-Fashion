@extends('adminelite::layouts.master')

@section('title')

@endsection

@section('custom-css')

@endsection

@section('page-name')
{{-- content after bread crumb --}}
@endsection

@section('content')

@endsection

@section('custom-js')

@endsection